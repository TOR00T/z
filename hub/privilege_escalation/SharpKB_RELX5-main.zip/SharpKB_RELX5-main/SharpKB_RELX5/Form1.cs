﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SharpKB_RELX5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (ComboBox comboBox in new ComboBox[] { comboBox1, comboBox2, comboBox3 })
            {
                comboBox.SelectedIndex = 0;
            }
            DataTable_Load(null);
        }

        private void DataTable_Load(string kb)
        {
            if (!File.Exists(".\\windows.csv"))
            {
                DialogResult MsgBoxResult = MessageBox.Show("漏洞库文件windows.csv丢失",
                "提示",
                MessageBoxButtons.OK,
                MessageBoxIcon.Exclamation,
                MessageBoxDefaultButton.Button2);
                if (MsgBoxResult == DialogResult.OK)
                {
                    Environment.Exit(0);
                }
            }
            else
            {
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("序号", typeof(int));

                string[] columnNames = { "漏洞编号", "漏洞类型", "影响版本", "补丁编号", "漏洞详情", "补丁地址" };
                System.Windows.Forms.CheckBox[] checkBoxes = { checkBox1, checkBox3, checkBox5, checkBox2, checkBox4, checkBox6 };

                bool anyCheckBoxChecked = false;

                for (int i = 0; i < columnNames.Length; i++)
                {
                    if (checkBoxes[i].Checked)
                    {
                        anyCheckBoxChecked = true;
                        dataTable.Columns.Add(columnNames[i]);
                    }
                }

                using (StreamReader streamReader = new StreamReader(".\\windows.csv"))
                {
                    string headerLine = streamReader.ReadLine();
                    string[] headerColumns = headerLine.Split(',');

                    foreach (string columnName in headerColumns)
                    {
                        if (dataTable.Columns.Contains(columnName))
                        {
                            this.dataGridView1.Columns.Add(columnName, columnName);
                        }
                    }

                    while (!streamReader.EndOfStream)
                    {
                        string dataLine = streamReader.ReadLine();
                        string[] rowData = dataLine.Split(',');

                        DataRow row = dataTable.NewRow();
                        if (dataTable.Columns.Contains("序号"))
                        {
                            row["序号"] = int.Parse(rowData[0]);
                        }

                        for (int i = 0; i < columnNames.Length; i++)
                        {
                            if (checkBoxes[i].Checked && dataTable.Columns.Contains(columnNames[i]))
                            {
                                row[columnNames[i]] = rowData[i + 1];
                            }
                        }

                        dataTable.Rows.Add(row);
                    }
                }

                if (!anyCheckBoxChecked)
                {
                    dataTable.Rows.Clear();
                    dataTable.Clear();
                    dataGridView1.Columns.Clear();
                }
                if (this.comboBox1.SelectedIndex == 0 && this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 0)
                {
                    dataGridView1.DataSource = dataTable;
                }
                else if (this.comboBox1.SelectedIndex == 0)
                {
                    if (this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 0)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()))
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 0)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()))
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()) && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                }
                else
                {
                    if (this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 0)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString())
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 0 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 0)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString())
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 1 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 0)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString())
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 1)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Privilege Escalation")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                    else if (this.comboBox2.SelectedIndex == 2 && this.comboBox3.SelectedIndex == 2)
                    {
                        DataTable filteredDataTable = dataTable.Clone();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            if (!kb.Contains(row["补丁编号"].ToString()) && row["影响版本"].ToString() == this.comboBox1.SelectedItem.ToString() && row["漏洞类型"].ToString() == "Remote Code Execution")
                            {
                                filteredDataTable.ImportRow(row);
                            }
                        }
                        dataGridView1.DataSource = filteredDataTable;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.textBox1.Text == "")
            {
                MessageBox.Show("请将补丁号或systeminfo信息复制到文本框");
            }
            else
            {
                try
                {
                    if (Regex.IsMatch(this.textBox1.Text, "OS Name:\\s+(.*)|OS 名称:\\s+(.+)"))
                    {
                        Regex regex1 = new Regex("OS Name:\\s+(.*)|OS 名称:\\s+(.+)");
                        string text1 = regex1.Match(this.textBox1.Text).Groups[1].Value;
                        string text2 = regex1.Match(this.textBox1.Text).Groups[2].Value;
                        this.label1.Text = "目标系统:\n" + (string.IsNullOrEmpty(text1) ? text2 : text1);
                    }
                    if (Regex.IsMatch(this.textBox1.Text, "OS Version:\\s+(.*)|OS 版本:\\s+(.*)"))
                    {
                        Regex regex1 = new Regex("OS Version:\\s+(.*)|OS 版本:\\s+(.*)");
                        string text3 = regex1.Match(this.textBox1.Text).Groups[1].Value;
                        string text4 = regex1.Match(this.textBox1.Text).Groups[2].Value;
                        this.label2.Text = "目标版本:\n" + (string.IsNullOrEmpty(text3) ? text4 : text3);
                    }

                    this.CheckKB();
                }
                catch (Exception ex)
                {
                    this.label1.Text = "目标系统:";
                    this.label2.Text = "目标版本:";
                }
            }
        }
        private void CheckKB()
        {
            Regex regex3 = new Regex(@"([KB])+(\d{4}\d*)");
            MatchCollection matches = regex3.Matches(this.textBox1.Text);
            List<string> kbList = new List<string>();
            foreach (Match match in matches)
            {
                kbList.Add("'" + match.Value + "'");
            }

            string kb = string.Join(",", kbList.ToArray());
            DataTable_Load(kb);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.textBox2.Text == "")
            {
                MessageBox.Show("请将tasklist /SVC 信息复制到文本框");
            }
            else
            {
                this.textBox3.Clear();
                Dictionary<string, string> av_list = new Dictionary<string, string>();
                av_list.Add("360tray.exe", "360安全卫士-实时保护");
                av_list.Add("360safe.exe", "360安全卫士-主程序");
                av_list.Add("ZhuDongFangYu.exe", "360安全卫士-主动防御");
                av_list.Add("360sd.exe", "360杀毒");
                av_list.Add("a2guard.exe", "a-squared杀毒");
                av_list.Add("ad-watch.exe", "Lavasoft杀毒");
                av_list.Add("cleaner8.exe", "The Cleaner杀毒");
                av_list.Add("vba32lder.exe", "vb32杀毒");
                av_list.Add("MongoosaGUI.exe", "Mongoosa杀毒");
                av_list.Add("CorantiControlCenter32.exe", "Coranti2012杀毒");
                av_list.Add("F-PROT.exe", "F-Prot AntiVirus");
                av_list.Add("CMCTrayIcon.exe", "CMC杀毒");
                av_list.Add("K7TSecurity.exe", "K7杀毒");
                av_list.Add("UnThreat.exe", "UnThreat杀毒");
                av_list.Add("CKSoftShiedAntivirus4.exe", "Shield Antivirus杀毒");
                av_list.Add("AVWatchService.exe", "VIRUSfighter杀毒");
                av_list.Add("ArcaTasksService.exe", "ArcaVir杀毒");
                av_list.Add("iptray.exe", "Immunet杀毒");
                av_list.Add("PSafeSysTray.exe", "PSafe杀毒");
                av_list.Add("nspupsvc.exe", "nProtect杀毒");
                av_list.Add("SpywareTerminatorShield.exe", "SpywareTerminator杀毒");
                av_list.Add("BKavService.exe", "Bkav杀毒");
                av_list.Add("MsMpEng.exe", "Microsoft Security Essentials");
                av_list.Add("SBAMSvc.exe", "VIPRE");
                av_list.Add("ccSvcHst.exe", "Norton杀毒");
                av_list.Add("f-secure.exe", "冰岛");
                av_list.Add("avp.exe", "Kaspersky");
                av_list.Add("KvMonXP.exe", "江民杀毒");
                av_list.Add("RavMonD.exe", "瑞星杀毒");
                av_list.Add("Mcshield.exe", "Mcafee");
                av_list.Add("Tbmon.exe", "Mcafee");
                av_list.Add("Frameworkservice.exe", "Mcafee");
                av_list.Add("egui.exe", "ESET NOD32");
                av_list.Add("ekrn.exe", "ESET NOD32");
                av_list.Add("eguiProxy.exe", "ESET NOD32");
                av_list.Add("kxetray.exe", "金山毒霸");
                av_list.Add("knsdtray.exe", "可牛杀毒");
                av_list.Add("TMBMSRV.exe", "趋势杀毒");
                av_list.Add("avcenter.exe", "Avira(小红伞)");
                av_list.Add("avguard.exe", "Avira(小红伞)");
                av_list.Add("avgnt.exe", "Avira(小红伞)");
                av_list.Add("sched.exe", "Avira(小红伞)");
                av_list.Add("ashDisp.exe", "Avast网络安全");
                av_list.Add("rtvscan.exe", "诺顿杀毒");
                av_list.Add("ccapp.exe", "Symantec Norton");
                av_list.Add("NPFMntor.exe", "Norton杀毒软件相关进程");
                av_list.Add("ccSetMgr.exe", "赛门铁克");
                av_list.Add("ccRegVfy.exe", "Norton杀毒软件自身完整性检查程序");
                av_list.Add("vptray.exe", "Norton病毒防火墙-盾牌图标程序");
                av_list.Add("ksafe.exe", "金山卫士");
                av_list.Add("QQPCRTP.exe", "QQ电脑管家");
                av_list.Add("Miner.exe", "流量矿石");
                av_list.Add("AYAgent.exe", "韩国胶囊");
                av_list.Add("patray.exe", "安博士");
                av_list.Add("V3Svc.exe", "安博士V3");
                av_list.Add("avgwdsvc.exe", "AVG杀毒");
                av_list.Add("QUHLPSVC.exe", "QUICK HEAL杀毒");
                av_list.Add("mssecess.exe", "微软杀毒");
                av_list.Add("SavProgress.exe", "Sophos杀毒");
                av_list.Add("fsavgui.exe", "F-Secure杀毒");
                av_list.Add("vsserv.exe", "比特梵德");
                av_list.Add("remupd.exe", "熊猫卫士");
                av_list.Add("FortiTray.exe", "飞塔");
                av_list.Add("safedog.exe", "安全狗");
                av_list.Add("parmor.exe", "木马克星");
                av_list.Add("Iparmor.exe.exe", "木马克星");
                av_list.Add("beikesan.exe", "贝壳云安全");
                av_list.Add("KSWebShield.exe", "金山网盾");
                av_list.Add("TrojanHunter.exe", "木马猎手");
                av_list.Add("GG.exe", "巨盾网游安全盾");
                av_list.Add("adam.exe", "绿鹰安全精灵");
                av_list.Add("AST.exe", "超级巡警");
                av_list.Add("ananwidget.exe", "墨者安全专家");
                av_list.Add("AVK.exe", "GData");
                av_list.Add("avg.exe", "AVG Anti-Virus");
                av_list.Add("spidernt.exe", "Dr.web");
                av_list.Add("avgaurd.exe", "Avira Antivir");
                av_list.Add("vsmon.exe", "ZoneAlarm");
                av_list.Add("cpf.exe", "Comodo");
                av_list.Add("outpost.exe", "Outpost Firewall");
                av_list.Add("rfwmain.exe", "瑞星防火墙");
                av_list.Add("kpfwtray.exe", "金山网镖");
                av_list.Add("FYFireWall.exe", "风云防火墙");
                av_list.Add("MPMon.exe", "微点主动防御");
                av_list.Add("pfw.exe", "天网防火墙");
                av_list.Add("1433.exe", "在扫1433");
                av_list.Add("DUB.exe", "在爆破");
                av_list.Add("ServUDaemon.exe", "发现S-U");
                av_list.Add("BaiduSdSvc.exe", "百度杀毒-服务进程");
                av_list.Add("BaiduSdTray.exe", "百度杀毒-托盘进程");
                av_list.Add("BaiduSd.exe", "百度杀毒-主程序");
                av_list.Add("SafeDogGuardCenter.exe", "安全狗");
                av_list.Add("safedogupdatecenter.exe", "安全狗");
                av_list.Add("safedogguardcenter.exe", "安全狗");
                av_list.Add("SafeDogSiteIIS.exe", "安全狗");
                av_list.Add("SafeDogTray.exe", "安全狗");
                av_list.Add("SafeDogServerUI.exe", "安全狗");
                av_list.Add("D_Safe_Manage.exe", "D盾");
                av_list.Add("d_manage.exe", "D盾");
                av_list.Add("yunsuo_agent_service.exe", "云锁");
                av_list.Add("yunsuo_agent_daemon.exe", "云锁");
                av_list.Add("HwsPanel.exe", "护卫神");
                av_list.Add("hws_ui.exe", "护卫神");
                av_list.Add("hws.exe", "护卫神");
                av_list.Add("hwsd.exe", "护卫神");
                av_list.Add("hipstray.exe", "火绒");
                av_list.Add("wsctrl.exe", "火绒");
                av_list.Add("usysdiag.exe", "火绒");
                av_list.Add("WEBSCANX.EXE", "网络病毒克星");
                av_list.Add("SPHINX.EXE", "SPHINX防火墙");
                av_list.Add("bddownloader.exe", "百度卫士");
                av_list.Add("baiduansvx.exe", "百度卫士-主进程");
                av_list.Add("AvastUI.exe", "Avast!5主程序");

                string avRes = this.textBox2.Text;
                string matchedRes = "";
                foreach (var eachRes in av_list)
                {
                    if (avRes.IndexOf(eachRes.Key) != -1)
                    {
                        matchedRes += eachRes.Key + ":" + eachRes.Value + "\r\n";
                    }
                }

                if (!string.IsNullOrEmpty(matchedRes))
                {
                    this.textBox3.AppendText("存在的杀软信息如下：\r\n" + matchedRes);
                }
                else
                {
                    this.textBox3.AppendText("暂未发现杀软信息");
                }
            }
        }
    }
}
