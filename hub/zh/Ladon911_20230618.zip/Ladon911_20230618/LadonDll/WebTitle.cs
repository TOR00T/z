using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Text.RegularExpressions;

namespace LadonDLL
{
    public class scan
    {
        public static string run(string input)
        {
            if (string.IsNullOrEmpty(input))
                return "";

            string url = "";
            Uri uriResult;
            if (Uri.TryCreate(input, UriKind.Absolute, out uriResult)
                && (uriResult.Scheme == Uri.UriSchemeHttp || uriResult.Scheme == Uri.UriSchemeHttps))
            {
                url = uriResult.ToString();
            }
            else if (Regex.IsMatch(input, @"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(:\d+)?$"))
            {
                url = "http://" + input;
            }

            if (string.IsNullOrEmpty(url))
            {
                return "Invalid URL or IP address";
            }
            else
            {
                string title = "";
                try
                {
                    WebClient client = new WebClient();
                    string html = client.DownloadString(url);
                    Regex regex = new Regex(@"(?<=<title.*>)([\s\S]*)(?=</title>)", RegexOptions.IgnoreCase);
                    title = regex.Match(html).Value.Trim();
                }
                catch
                {
                    return "";
                }
                return url + "\t" + title + "\r\n";
            }
        }
    }
}
