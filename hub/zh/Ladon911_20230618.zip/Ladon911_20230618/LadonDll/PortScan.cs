using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;

namespace LadonDLL
{
    public class scan
    {
        public static string run(string ip)
        {
            if (string.IsNullOrEmpty(ip))
                return "";

            // 要扫描的端口列表
            List<int> ports = new List<int>() { 21, 80, 443, 22, 445, 135 };

            string result = "";

            // 扫描每个端口并添加结果到字符串
            foreach (int port in ports)
            {
                if (IsPortOpen(ip, port))
                {
                    result += $"{ip}\t{port}\tOPEN\r\n";
                }
            }

            return result;
        }

        // 检查端口是否开放
        static bool IsPortOpen(string ip, int port)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    client.Connect(ip, port);
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
